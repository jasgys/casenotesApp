var express = require('express');
var crypto = require('crypto');
var mysql = require('mysql');

var router = express.Router();

var connection = mysql.createConnection({
  host     : 'm7wltxurw8d2n21q.cbetxkdyhwsb.us-east-1.rds.amazonaws.com',
  user     : 'zib2z7pklhcahunp',
  password : 'tzdocp7q8oe5vbfc',
  database : 'qjio44t1wsi1j1ss'
});

connection.connect();

const regExpYouthPriKey = /Duplicate entry .* for key 'PRIMARY'/g;
const regExpYouthMobile = /Duplicate entry .* for key 'mobileNum'/g;
const regExpYouthNRIC = /Duplicate entry .* for key 'nricNum'/g;

const woodlandsCentreAddr_Line1 = 'Block 804, Woodlands Street 81, #01-37';
const woodlandsCentreAddr_Line2 = 'Singapore 730804, Tel: +65-6368 8392; Fax: +65-6368 6642';
const amkCentreAddr_Line1 = 'Block 125, Ang Mo Kio Ave 6, #01-4077';
const amkCentreAddr_Line2 = 'Singapore 560125, Tel: +65-6451 6519';
const geylangCentreAddr_Line1 = 'Block 10, Lorong 27A, Geylang Emmanuel House, #03-01';
const geylangCentreAddr_Line2 = 'Singapore 388107, Tel: +65-6745 1490';


function checkLogin(req, res, next) {
  if (req.session.user) {
    next();
  } else {
    res.redirect('/login');
  }
}

router.get('/login', function(req, res, next) {
  res.render('login', { error: false, message: req.query.msg, user: '' });
});

router.post('/login', function(req, res, next) {
	var userAuthenticationQuery = 'SELECT * FROM Users u WHERE u.userID = \'' + req.body.username + '\';';
	var setTimeZoneQuery = 'SET time_zone = \'Asia/Singapore\';';

	connection.query(userAuthenticationQuery, function(err, user, fields) {
	  var inputHash = crypto.createHmac('md5', req.body.username).update(req.body.password).digest('hex');

	  if (user.length && inputHash == user[0].md5Hash) {
	    var sess = req.session;
	    sess.user = req.body.username;
	    sess.centre = user[0].centre
	    sess.action = 'home';
	    sess.manageTab = 'Youth';
	    sess.message = '';

	    sess.youth = { action: '',
	    							 name: '',
	    							 school: '',
	    							 nricNum: '',
	    							 membershipNum: '',
	    							 gender: '',
	    							 address: '',
	    							 mobileNum: '',
	    							 dateOfBirth: '',
	    							 membershipFeePaid: '',
	    							 errorMsg: '' };

	    sess.activity = { activityType: '',
												topic: '',
												date: '',
												errorMsg: '' };

	    sess.attends = { action: '',
	    								 memberNum: '',
	    								 sports: false,
	    								 dropIn: '',
	    								 errorMsg: '' };

	    sess.mentee = { myasPreScore: 0,
	    								myasPostScore: 0 };

	    sess.pydi = { pydiPreScore: 0,
	    							pydiPostScore: 0 };

	    sess.member = null;
	    sess.attendRec = null;
	    sess.actRecord = null;

	    connection.query(setTimeZoneQuery, function(err, user, fields) {
	    	if (err) throw err;

	    	res.redirect('/');
	    });
	  } else {
	    res.render('login', { error: true, user: req.body.username });  
	  }
	});
});

router.get('/logout', function(req, res, next) {
  if (req.session.user) {
    req.session.destroy(function(err) {
      if(err) {
        console.log(err);
      } else {
        res.redirect('/login');
      }
    });
  } else {
    res.redirect('/login');
  }
});

router.get('/changePassword', function(req, res, next) {
	res.render('changePassword', { error: false, user: '' });
});

router.post('/changePassword', function(req, res, next) {
	var newHash = crypto.createHmac('md5', req.body.username).update(req.body.newPassword).digest('hex');
	var newCHash = crypto.createHmac('md5', req.body.username).update(req.body.cNewPassword).digest('hex');
	var oldHash = crypto.createHmac('md5', req.body.username).update(req.body.oldPassword).digest('hex');

	if (newHash != newCHash) {
		res.render('changePassword', { errorMsg: 'New passwords not the same!', user: req.body.username });
	} else {
		var validUserQuery = 'SELECT * FROM Users u WHERE u.userID = \'' + req.body.username + '\';';

		connection.query(validUserQuery, function(err, user, fields) {

			if (user.length && oldHash == user[0].md5Hash) {
				
				var changePasswordQuery = 'UPDATE Users SET md5Hash = \'' + newHash + '\' WHERE userID = \'' + req.body.username + '\';';

				connection.query(changePasswordQuery, function(err, user, fields) {
					if (err) throw err;

					var string = encodeURIComponent('Password for ' + req.body.username + ' successfully changed!');
					res.redirect('/login?msg=' + string);
				});
			} else {
				res.render('changePassword', { errorMsg: 'Username or Old Password incorrect!', user: req.body.username });
			}
		});
	}
});

router.get('/', checkLogin, function(req, res, next) {
	req.session.action = 'home';
  res.render('home', { centre: req.session.centre, 
  										 currAction: req.session.action, 
  										 message: 'Welcome to YGOS ELMP Portal.' });
});

router.get('/youth', checkLogin, function(req, res, next) {
	req.session.action = 'register';	
	req.session.youth.action = 'Register';
  res.render('youth', { centre: req.session.centre, 
  											currAction: req.session.action, 
  											formTitle:  'Register a new Youth',
  											formAction: '/youth',
  											youth: req.session.youth,
  											message: req.query.msg });
});

router.post('/youth', checkLogin, function(req, res, next) {

	var insertYouthQuery = 'INSERT INTO Youth (name, ' + 
																						'school, ' + 
																						'nricNum, ' + 
																						'gender, ' + 
																						'address, ' +
																						'mobileNum, ' + 
																						'parentMobileNum, ' + 
																						'dateOfBirth, ' + 
																						'dateOfReg, ' +
																						'centre) ' + 
														 'VALUES (\'' + req.body.name + '\', \'' + 
																						req.body.school + '\', UCASE(\'' + 
																						req.body.nricNum + '\'), \'' +
																						req.body.gender + '\', \'' + 
																						req.body.address + '\', ' +
																						req.body.mobileNum + ', ' + 
																						(req.body.parentMobileNum ? req.body.parentMobileNum : 'NULL') + ', \'' + 
																						req.body.dateOfBirth + 
																						'\', CURDATE(), \'' +
																						req.session.centre + '\');';

	var insertPaymentRecordQuery = 'INSERT INTO Payment (youthNricNum, ' + 
																											'youthCentre, ' +
																											'paymentDate, ' + 
																											'paymentAmt)' + 
																			 'VALUES (\'' + req.body.nricNum + '\', \'' +
																											req.session.centre + '\', ' +
																											'CURDATE(), ' +
																											req.body.membershipFeePaid + ');';

	var insertPYDIRecordQuery = 'INSERT INTO PYDI (youthNricNum, ' + 
																								'youthCentre, ' +
																								'preScore, ' + 
																								'postScore, ' +
																								'scoreDate, ' + 
																								'scoreValidity)' + 
																 'VALUES (\'' + req.body.nricNum + '\', \'' +
																								req.session.centre + '\', ' +
																								'NULL, NULL, CURDATE(), YEAR(CURDATE()));';


	connection.query(insertYouthQuery, function(err, rows, fields) {
	  if (err) {
	  	switch (err.code) {
	  		case 'ER_SIGNAL_EXCEPTION':
	  			req.session.youth.errorMsg = err.message.substring(21);
	  			break;

  			case 'ER_DUP_ENTRY':
  				if (regExpYouthPriKey.test(err.message)) {
  					req.session.youth.errorMsg = 'Specified NRIC NUMBER is already registered.';
  				} else if (regExpYouthMobile.test(err.message)) {
  					req.session.youth.errorMsg = 'Specified MOBILE NUMBER is already registered.';
  				}
  				break;

  			default:
  				console.log('youth error:', err);
  				break;
	  	}

	  	req.session.youth.name = req.body.name;
	  	req.session.youth.school = req.body.school;
	  	req.session.youth.nricNum = req.body.nricNum;
	  	req.session.youth.gender = req.body.gender;
	  	req.session.youth.address = req.body.address;
	  	req.session.youth.mobileNum = req.body.mobileNum;
	  	req.session.youth.parentMobileNum = req.body.parentMobileNum;
	  	req.session.youth.dateOfBirth = req.body.dateOfBirth;
	  	req.session.youth.membershipFeePaid = req.body.membershipFeePaid;

	  	res.redirect('/youth');

	  } else if (req.body.membershipFeePaid > 0) {
	  	connection.query(insertPaymentRecordQuery, function(err, rows, fields) {
	  		if (err) {
	  			switch (err.code) {
						case 'ER_DUP_ENTRY':
							req.session.youth.errorMsg = 'Payment installment record already entered for today.';
		  				break;

		  			default:
		  				console.log('payment error:', err);
  						break;
					}

					res.redirect('/Youth/');

	  		} else {

	  			for (item in req.session.youth) {
			  		req.session.youth[item] = '';
			  	}

			  	connection.query(insertPYDIRecordQuery, function(err, rows, fields) {
	  				if (err) throw err;

				  	var string = encodeURIComponent(req.body.nricNum + ' ' + req.body.name + ' successfully registered!');
				  	res.redirect('/youth?msg=' + string);
				  });
	  		}
		  });

	  } else {

	  	for (item in req.session.youth) {
	  		req.session.youth[item] = '';
	  	}

	  	connection.query(insertPYDIRecordQuery, function(err, rows, fields) {
				if (err) throw err;

		  	var string = encodeURIComponent(req.body.nricNum + ' ' + req.body.name + ' successfully registered!');
		  	res.redirect('/youth?msg=' + string);
		  });
	  }
	});
});

router.get('/activity', checkLogin, function(req, res, next) {
	req.session.action = 'register';
  res.render('activity', { centre: req.session.centre, 
	  											 currAction: req.session.action, 
	  											 formTitle: 'Register a new Activity',
	  											 formAction: '/activity', 
	  											 activity: req.session.activity,
	  											 message: req.query.msg });
});

router.post('/activity', checkLogin, function(req, res, next) {
	var activityTopic = '';

	if (req.body.topicOption == 'dropIn') {
		activityTopic = 'Drop In: ' + req.body.topicDesc;
	} else if (req.body.topicOption == 'elLesson') {
		activityTopic = 'EL Lesson: ' + req.body.topicDesc;
	} else {
		console.log('Invalid activity topic.');
		throw err('Invalid activity topic.');
	}

	var insertActivityQuery = 'INSERT INTO Activity (activityDate, centre, topic) VALUES (\'' + 
																req.body.dateOfActivity + '\', \'' + 
																req.session.centre + '\', \'' + 
																activityTopic + '\');';

	connection.query(insertActivityQuery, function(err, rows, fields) {
	  if (err) {
	  	switch (err.code) {
	  		case 'ER_SIGNAL_EXCEPTION':
	  			req.session.activity.errorMsg = err.message.substring(21);
	  			break;

  			case 'ER_DUP_ENTRY':
  				req.session.activity.errorMsg = 'Specified activity has been created already.';
  				break;
	  	}

	  	req.session.activity.activityType = req.body.activityType;
	  	req.session.activity.topic = req.body.topicDesc;
	  	req.session.activity.date = req.body.dateOfActivity;

	  	res.redirect('/activity');

	  } else {
	  	for (item in req.session.activity) {
	  		req.session.activity[item] = '';
	  	}
	  	var string = encodeURIComponent(activityTopic + ' successfully created!');
  		res.redirect('/activity?msg=' + string);
	  }
	});
});

router.get('/checkIn', checkLogin, function(req, res, next) {
	req.session.action = 'register';
	req.session.attends.action = 'In';

	var currDayActivitiesQuery = 'SELECT *' + 
															' FROM Activity a' + 
															' WHERE a.centre = \'' + req.session.centre +
														'\' AND MONTH(a.activityDate) >= MONTH(CURDATE()) - 1' +
															' AND MONTH(a.activityDate) <= MONTH(CURDATE())' +
															' AND YEAR(a.activityDate) = YEAR(CURDATE())' + 
															' ORDER BY a.activityDate DESC;';

	var nameNricListQuery = 'SELECT y.nricNum, y.name' +
												 ' FROM Youth y' +
												 ' WHERE y.centre = \'' + req.session.centre + '\';';

	var currDateQuery = 'SELECT CURDATE() AS currDate;';

  connection.query(currDayActivitiesQuery, function(err, activities, fields) {
  	if (err) throw err;

  	connection.query(nameNricListQuery, function(err, nameNricList, fields) {
	  	if (err) throw err;

	  	connection.query(currDateQuery, function(err, currDate, fields) {
		  	if (err) throw err;
		  	
		  	var parsedNameNricList = [];

		  	for (var i = 0; i < nameNricList.length; i++) {
		  		var memStr = nameNricList[i].nricNum + ' ' + nameNricList[i].name;
		  		parsedNameNricList.push(memStr);
		  	}

			  res.render('checkInOut', { centre: req.session.centre, 
					  											 currAction: req.session.action, 
					  											 formTitle: 'Check In',
					  											 formAction: '/checkIn', 
					  											 attends: req.session.attends,
					  											 activities: activities,
					  											 currDate: currDate[0].currDate,
					  											 nameNricList: parsedNameNricList,
					  											 message: req.query.msg });
			});
		});
	});
});

router.post('/checkIn', checkLogin, function(req, res, next) {
	var activityDetails = req.body.activity.split(',');

	var insertAttendsQuery = 'INSERT INTO Attends (startTime, endTime, youthNricNum, youthCentre, activityDate, activityCentre, activityTopic) VALUES (\'' + 
															req.body.timeOfRecord +
															'\', NULL, \'' + 
															req.body.name.substr(0, 9).toUpperCase() + '\', \'' + 
															req.session.centre + '\', \'' +
															activityDetails[0] + '\', \'' +
															req.session.centre + '\', \'' + 
															activityDetails[1] + '\');';

	connection.query(insertAttendsQuery, function(err, rows, fields) {
	  if (err) {
	  	switch (err.code) {
	  		case 'ER_SIGNAL_EXCEPTION':
	  			req.session.attends.errorMsg = err.message.substring(21);
	  			break;

	  		case 'ER_NO_REFERENCED_ROW_2':
	  			req.session.attends.errorMsg = 'No such youth ' + req.body.name + ' registered.';
	  			break;

	  		case 'ER_DUP_ENTRY':
	  			req.session.attends.errorMsg = 'Youth already checked in for the selected activity.'
	  			break;

	  		default:
	  			console.log(err);
	  	}

	  	req.session.attends.member = req.body.name;
	  	res.redirect('/checkIn');

	  } else {
	  	for (item in req.session.attends) {
	  		req.session.attends[item] = '';
	  	}
	  	var string = encodeURIComponent('Attendance for youth ' + req.body.name + ' recorded!');
  		res.redirect('/checkIn?msg=' + string);
	  }
	});
});

router.get('/checkOut', checkLogin, function(req, res, next) {
	req.session.action = 'register';
	req.session.attends.action = 'Out';

	var currDayActivitiesQuery = 'SELECT *' + 
															' FROM Activity a' + 
															' WHERE a.centre = \'' + req.session.centre +
														'\' AND MONTH(a.activityDate) >= MONTH(CURDATE()) - 1' +
															' AND MONTH(a.activityDate) <= MONTH(CURDATE())' +
															' AND YEAR(a.activityDate) = YEAR(CURDATE())' + 
															' ORDER BY a.activityDate DESC;';

	var nameNricListQuery = 'SELECT y.nricNum, y.name' +
												 ' FROM Youth y' +
												 ' WHERE y.centre = \'' + req.session.centre + '\';';

	var currDateQuery = 'SELECT CURDATE() AS currDate;';

	connection.query(currDayActivitiesQuery, function(err, activities, fields) {
  	if (err) throw err;

		connection.query(nameNricListQuery, function(err, nameNricList, fields) {
			if (err) throw err;

			connection.query(currDateQuery, function(err, currDate, fields) {
		  	if (err) throw err;

				var parsedNameNricList = [];

				for (var i = 0; i < nameNricList.length; i++) {
					var memStr = nameNricList[i].nricNum + ' ' + nameNricList[i].name;
					parsedNameNricList.push(memStr);
				}

				res.render('checkInOut', { centre: req.session.centre, 
					  											 currAction: req.session.action, 
					  											 formTitle: 'Check Out',
					  											 formAction: '/checkOut', 
					  											 attends: req.session.attends,
					  											 activities: activities,
					  											 currDate: currDate[0].currDate,
					  											 nameNricList: parsedNameNricList,
					  											 message: req.query.msg });
			});
		});
	});
});

router.post('/checkOut', checkLogin, function(req, res, next) {
	var activityDetails = req.body.activity.split(',');

	var updateAttendsQuery = 'UPDATE Attends' + 
													' SET endTime = \'' + req.body.timeOfRecord +
												'\' WHERE youthNricNum = \'' + req.body.name.substr(0, 9).toUpperCase() + 
												'\' AND youthCentre = \'' + req.session.centre + 
												'\' AND activityDate = \'' + activityDetails[0] +
												'\' AND activityCentre = \'' + req.session.centre + 
												'\' AND activityTopic = \'' + activityDetails[1] +
												'\' AND endTime IS NULL;';

	var isNricNumValidQuery = 'SELECT (' +
															'NOT EXISTS (' +
																'SELECT * FROM Youth y' +
																' WHERE y.nricNum = \'' + req.body.name.substr(0, 9).toUpperCase() + 
															'\' AND y.centre = \'' + req.session.centre + '\')) as isNricNumValid;';

	var hasMemberCheckedOutQuery = 'SELECT (' +
																	'EXISTS (' +
																		'SELECT * FROM Attends a' +
																		' WHERE a.youthNricNum = \'' + req.body.name.substr(0, 9).toUpperCase() + 
																	'\' AND a.activityDate = \'' + activityDetails[0] +
																	'\' AND a.activityCentre = \'' + req.session.centre + 
																	'\' AND a.youthCentre = \'' + req.session.centre + 
																	'\' AND a.activityTopic = \'' + activityDetails[1] +
																	'\' AND a.endTime IS NOT NULL)) as hasMemberCheckedOut;';

	var hasMemberCheckedInQuery = 'SELECT (' +
																	'NOT EXISTS (' +
																		'SELECT * FROM Attends a' +
																		' WHERE a.youthNricNum = \'' + req.body.name.substr(0, 9).toUpperCase() + 
																	'\' AND a.activityDate = \'' + activityDetails[0] +
																	'\' AND a.activityCentre = \'' + req.session.centre + 
																	'\' AND a.activityTopic = \'' + activityDetails[1] +
																	'\' AND a.youthCentre = \'' + req.session.centre + '\')) as hasMemberCheckedIn;';

	connection.query(isNricNumValidQuery, function(err, isNricNumValid, fields) {
		if (isNricNumValid[0].isNricNumValid) {
			req.session.attends.errorMsg = 'Youth is not registered.';
			req.session.attends.member = req.body.name;
			res.redirect('/checkOut');

		} else {
			connection.query(hasMemberCheckedOutQuery, function(err, hasMemberCheckedOut, fields) {
				if (hasMemberCheckedOut[0].hasMemberCheckedOut) {
					req.session.attends.errorMsg = 'Youth has already checked out of the selected activity.';
					req.session.attends.member = req.body.name;
					res.redirect('/checkOut');
				} else {

					connection.query(hasMemberCheckedInQuery, function(err, hasMemberCheckedIn, fields) {
						if (hasMemberCheckedIn[0].hasMemberCheckedIn) {
							req.session.attends.errorMsg = 'Youth did not check in for the selected activity.';
							req.session.attends.member = req.body.name;
							res.redirect('/checkOut');

						} else {
							connection.query(updateAttendsQuery, function(err, rows, fields) {
								if (err) throw err;

								for (item in req.session.attends) {
									req.session.attends[item] = '';
								}
								var string = encodeURIComponent('Attendance for Youth ' + req.body.name + ' updated!');
								res.redirect('/checkOut?msg=' + string);	
							});
						}
					});
				}
			});
		}
	});
});

router.get('/activityRec', checkLogin, function(req, res, next) {
	req.session.action = 'export';
  res.render('actAttend', { centre: req.session.centre, 
  													currAction: req.session.action,
  													attendsType: 'all',
  													queryMethod: 'activityRec',
  													date: '' });
});

router.post('/activityRec', checkLogin, function(req, res, next) {
	var actRecordQuery = 'SELECT a.activityDate, y.name, y.gender, a.youthNricNum, y.school, m.membershipNum, a.activityTopic, a.startTime, a.endTime' +
											' FROM Attends a, Youth y LEFT JOIN Member m' +
											' ON y.nricNum = m.youthNricNum' +
											' AND y.centre = m.youthCentre' +
											' WHERE y.nricNum = a.youthNricNum' +
											' AND y.centre = a.youthCentre' +
											' AND a.activityCentre = \'' + req.session.centre + 
										'\' AND a.activityDate = \'' + req.body.date + 
										'\' ORDER BY m.membershipNum, y.school ASC;';

  connection.query(actRecordQuery, function(err, actRecord, fields) {
	  if (err) throw err;

	  req.session.actRecord = actRecord;

	  res.render('actAttend', { centre: req.session.centre, 
	  													currAction: req.session.action,
  														attendsType: 'all',
  														queryMethod: 'activityRec',
  														exportType: 'exportActivityRecPDF',
	  													date: req.body.date,
	  													actRecord: actRecord });
	});
});

router.get('/exportActivityRecPDF', checkLogin, function(req, res, next) {
	res.render('exportActivityRecPDF', { actRecord: req.session.actRecord,
																			 attendsType: 'All' });
});

router.get('/elActivityRec', checkLogin, function(req, res, next) {
	req.session.action = 'export';
  res.render('actAttend', { centre: req.session.centre, 
  													currAction: req.session.action,
  													attendsType: 'EL',
  													queryMethod: 'elActivityRec',
  													date: '' });
});

router.post('/elActivityRec', checkLogin, function(req, res, next) {
	var actRecordQuery = 'SELECT a.activityDate, y.name, y.gender, a.youthNricNum, y.school, m.membershipNum, a.activityTopic, a.startTime, a.endTime' +
											' FROM Attends a, Youth y LEFT JOIN Member m' +
											' ON y.nricNum = m.youthNricNum' +
											' AND y.centre = m.youthCentre' +
											' WHERE y.nricNum = a.youthNricNum' +
											' AND y.centre = a.youthCentre' +
											' AND a.activityCentre = \'' + req.session.centre + 
										'\' AND a.activityDate = \'' + req.body.date + 
										'\' AND a.activityTopic LIKE \'EL Lesson%' + 
										'\' ORDER BY m.membershipNum, y.school ASC;';

  connection.query(actRecordQuery, function(err, actRecord, fields) {
	  if (err) throw err;

	  req.session.actRecord = actRecord;

	  res.render('actAttend', { centre: req.session.centre, 
	  													currAction: req.session.action,
  														attendsType: 'EL',
  														queryMethod: 'elActivityRec',
  														exportType: 'exportElActivityRecPDF',
	  													date: req.body.date,
	  													actRecord: actRecord });
	});
});

router.get('/exportElActivityRecPDF', checkLogin, function(req, res, next) {
	res.render('exportActivityRecPDF', { actRecord: req.session.actRecord,
																			 attendsType: 'EL Lesson' });
});

router.get('/dropInActivityRec', checkLogin, function(req, res, next) {
	req.session.action = 'export';
  res.render('actAttend', { centre: req.session.centre, 
  													currAction: req.session.action,
  													attendsType: 'Drop In',
  													queryMethod: 'dropInActivityRec',
  													date: '' });
});

router.post('/dropInActivityRec', checkLogin, function(req, res, next) {
	var actRecordQuery = 'SELECT a.activityDate, y.name, y.gender, a.youthNricNum, y.school, m.membershipNum, a.activityTopic, a.startTime, a.endTime' +
											' FROM Attends a, Youth y LEFT JOIN Member m' +
											' ON y.nricNum = m.youthNricNum' +
											' AND y.centre = m.youthCentre' +
											' WHERE y.nricNum = a.youthNricNum' +
											' AND y.centre = a.youthCentre' +
											' AND a.activityCentre = \'' + req.session.centre + 
										'\' AND a.activityDate = \'' + req.body.date + 
										'\' AND a.activityTopic LIKE \'Drop In%' + 
										'\' ORDER BY m.membershipNum, y.school ASC;';

  connection.query(actRecordQuery, function(err, actRecord, fields) {
	  if (err) throw err;

	  req.session.actRecord = actRecord;

	  res.render('actAttend', { centre: req.session.centre, 
	  													currAction: req.session.action,
  														attendsType: 'Drop In',
  														queryMethod: 'dropInActivityRec',
  														exportType: 'exportDropInActivityRecPDF',
	  													date: req.body.date,
	  													actRecord: actRecord });
	});
});

router.get('/exportDropInActivityRecPDF', checkLogin, function(req, res, next) {
	res.render('exportActivityRecPDF', { actRecord: req.session.actRecord,
																			 attendsType: 'Drop-In' });
});

router.get('/indivRec', checkLogin, function(req, res, next) {
	req.session.action = 'export';

	var nameNricListQuery = 'SELECT y.nricNum, y.name' +
												 ' FROM Youth y' +
												 ' WHERE y.centre = \'' + req.session.centre + '\';';

	connection.query(nameNricListQuery, function(err, nameNricList, fields) {
		if (err) throw err;

		var parsedNameNricList = [];

		for (var i = 0; i < nameNricList.length; i++) {
			var memStr = nameNricList[i].nricNum + ' ' + nameNricList[i].name;
			parsedNameNricList.push(memStr);
		}

	  res.render('indivAttend', { centre: req.session.centre, 
	  														currAction: req.session.action,
	  														specifiedNameAndNric: '',
	  														startDate: '',
	  														endDate: '',
	  														nameNricList: parsedNameNricList });
	});
});

router.post('/indivRec', checkLogin, function(req, res, next) {

	var memberQuery = 'SELECT y.name, y.school, y.nricNum, y.gender, y.address, y.mobileNum, y.dateOfBirth, y.dateOfReg, y.dateOfExit, y.exitComments, y.centre, m.membershipNum' + 
									 ' FROM Youth y LEFT JOIN Member m' + 
									 ' ON y.nricNum = m.youthNricNum' + 
									 ' AND y.centre = m.youthCentre' + 
									 ' WHERE y.nricNum = \'' + req.body.name.substr(0, 9).toUpperCase() + 
								 '\' AND y.centre = \'' + req.session.centre + '\';';

	var attendsQuery = 'SELECT *' + 
										' FROM Attends a' + 
										' WHERE a.youthNricNum = \'' + req.body.name.substr(0, 9).toUpperCase() + 
								  '\' AND a.activityCentre = \'' + req.session.centre + 
								  '\' AND a.activityDate <= \'' + req.body.endDate + 
									'\' AND a.activityDate >= \'' + req.body.startDate + 
								  '\' ORDER BY a.activityDate ASC;';

	var nameNricListQuery = 'SELECT y.nricNum, y.name' +
												 ' FROM Youth y' +
												 ' WHERE y.centre = \'' + req.session.centre + '\';';

	connection.query(memberQuery, function(err, member, fields) {
		if (err) throw err;

		connection.query(attendsQuery, function(err, attendRec, fields) {
			if (err) throw err;

			connection.query(nameNricListQuery, function(err, nameNricList, fields) {
				if (err) throw err;

				var parsedNameNricList = [];

				for (var i = 0; i < nameNricList.length; i++) {
					var memStr = nameNricList[i].nricNum + ' ' + nameNricList[i].name;
					parsedNameNricList.push(memStr);
				}

				req.session.member = member;
				req.session.attendRec = attendRec;

				res.render('indivAttend', { centre: req.session.centre, 
			  														currAction: req.session.action,
			  														specifiedNameAndNric: req.body.name,
			  														member: member,
			  														attendRec: attendRec,
			  														startDate: req.body.startDate,
			  														endDate: req.body.endDate,
	  																nameNricList: parsedNameNricList });
			});
		});
	});
});

router.get('/exportIndivRecPDF', checkLogin, function(req, res, next) {
	var addrLine1 = '';
	var addrLine2 = '';

	switch (req.session.centre) {
		case 'Ang Mo Kio':
			addrLine1 = amkCentreAddr_Line1;
			addrLine2 = amkCentreAddr_Line2;
			break;

		case 'Woodlands':
			addrLine1 = woodlandsCentreAddr_Line1;
			addrLine2 = woodlandsCentreAddr_Line2;
			break;

		case 'Geylang':
			addrLine1 = geylangCentreAddr_Line1;
			addrLine2 = geylangCentreAddr_Line2;
			break;

		default:
			console.log('Invalid centre.');
			throw err('Invalid centre.');
	}

	res.render('exportIndivRecPDF', { member: req.session.member,
																		attendRec: req.session.attendRec,
																		addrLine1: addrLine1,
																		addrLine2: addrLine2 });
});

router.get('/paymentRec', checkLogin, function(req, res, next) {
	req.session.action = 'export';

	res.render('paymentRec', { centre: req.session.centre, 
  													 currAction: req.session.action,
  													 totalPaymentAmt: '',
  													 startDate: '',
  													 endDate: '' });
});

router.post('/paymentRec', checkLogin, function(req, res, next) {
	var totalPaymentQuery = 'SELECT SUM(p.paymentAmt) as totalPaymentAmt' +
												 ' FROM Payment p' +
												 ' WHERE p.paymentDate >= \'' + req.body.startDate + 
											 '\' AND p.paymentDate <= \'' + req.body.endDate + 
											 '\' AND p.youthCentre = \'' + req.session.centre + '\';';

	var paymentRecQuery = 'SELECT y.name, y.gender, p.youthNricNum, y.school, m.membershipNum, p.paymentDate, p.paymentAmt' +
											 ' FROM Payment p, Youth y LEFT JOIN Member m' +
											 ' ON y.nricNum = m.youthNricNum' +
											 ' AND y.centre = m.youthCentre' +
											 ' WHERE y.nricNum = p.youthNricNum' +
											 ' AND y.centre = p.youthCentre ' +
											 ' AND p.paymentDate >= \'' + req.body.startDate + 
										 '\' AND p.paymentDate <= \'' + req.body.endDate + 
										 '\' AND p.youthCentre = \'' + req.session.centre + 
										 '\' ORDER BY m.membershipNum, p.youthNricNum, p.paymentDate ASC;';

	connection.query(totalPaymentQuery, function(err, totalPayment, fields) {
		if (err) throw err;

		connection.query(paymentRecQuery, function(err, payment, fields) {
			if (err) throw err;

			req.session.paymentRec = payment;
			req.session.totalPaymentAmt = totalPayment[0].totalPaymentAmt;

			res.render('paymentRec', { centre: req.session.centre, 
		  													 currAction: req.session.action,
		  													 paymentRec: payment,
		  													 totalPaymentAmt: totalPayment[0].totalPaymentAmt,
		  													 startDate: req.body.startDate,
		  													 endDate: req.body.endDate });
		});
	});
});

router.get('/exportPaymentRecPDF', checkLogin, function(req, res, next) {
	var addrLine1 = '';
	var addrLine2 = '';

	switch (req.session.centre) {
		case 'Ang Mo Kio':
			addrLine1 = amkCentreAddr_Line1;
			addrLine2 = amkCentreAddr_Line2;
			break;

		case 'Woodlands':
			addrLine1 = woodlandsCentreAddr_Line1;
			addrLine2 = woodlandsCentreAddr_Line2;
			break;

		case 'Geylang':
			addrLine1 = geylangCentreAddr_Line1;
			addrLine2 = geylangCentreAddr_Line2;
			break;

		default:
			console.log('Invalid centre.');
			throw err('Invalid centre.');
	}

	res.render('exportPaymentRecPDF', { paymentRec: req.session.paymentRec,
																			totalPaymentAmt: req.session.totalPaymentAmt,
																			addrLine1: addrLine1,
																			addrLine2: addrLine2 });
});

router.get('/youthReachedRec', checkLogin, function(req, res, next) {
	req.session.action = 'export';

	res.render('youthReachRec', { centre: req.session.centre, 
		  													currAction: req.session.action,
		  													totalPaymentAmt: '',
		  													startDate: '',
		  													endDate: '' });
});

router.post('/youthReachedRec', checkLogin, function(req, res, next) {
	var totalYouthReachedQuery = 'SELECT COUNT(DISTINCT y.nricNum) as totalYouthsReached' +
															' FROM Youth y, Attends a' +
															' WHERE y.centre = \'' + req.session.centre + 
														'\' AND y.centre = a.youthCentre' +
															' AND y.nricNum = a.youthNricNum' +
															' AND a.activityDate >= \'' + req.body.startDate + 
														'\' AND a.activityDate <= \'' + req.body.endDate + '\';';

	var youthAttendanceRecQuery = 'SELECT yr.name, yr.gender, yr.nricNum, yr.school, yr.membershipNum, yr.activityDate, yr.activityTopic, cr.numAct' +
															 ' FROM (' +
																 ' SELECT y.name, y.gender, y.nricNum, y.school, m.membershipNum, a.activityDate, a.activityTopic' +
																 ' FROM Attends a, Youth y LEFT JOIN Member m' +
																 ' ON y.nricNum = m.youthNricNum' +
																 ' AND y.centre = m.youthCentre' +
																 ' WHERE y.centre = \'' + req.session.centre + 
															 '\' AND a.youthCentre = y.centre' +
																 ' AND a.youthNricNum = y.nricNum' +
																 ' AND a.activityDate >= \'' + req.body.startDate + 
															 '\' AND a.activityDate <= \'' + req.body.endDate + '\') yr' +
															 ' LEFT JOIN (' +
																 ' SELECT y.nricNum, COUNT(a.activityTopic) AS numAct' +
																 ' FROM Attends a, Youth y ' +
																 ' WHERE y.centre = \'' + req.session.centre + 
															 '\' AND a.youthCentre = y.centre' +
																 ' AND a.youthNricNum = y.nricNum' +
																 ' AND a.activityDate >= \'' + req.body.startDate + 
															 '\' AND a.activityDate <= \'' + req.body.endDate +
															 '\' GROUP BY y.nricNum) cr' +
															 ' ON yr.nricNum = cr.nricNum' +
															 ' ORDER BY yr.membershipNum, yr.nricNum ASC;';

	connection.query(totalYouthReachedQuery, function(err, totalYouthReached, fields) {
		if (err) throw err;

		connection.query(youthAttendanceRecQuery, function(err, youthAttendance, fields) {
			if (err) throw err;

			req.session.youthAttendance = youthAttendance;
			req.session.totalYouthReached = totalYouthReached[0].totalYouthsReached;

			res.render('youthReachRec', { centre: req.session.centre, 
				  													currAction: req.session.action,
				  													youthReachedRec: youthAttendance,
				  													totalYouthReached: totalYouthReached[0].totalYouthsReached,
				  													startDate: req.body.startDate,
				  													endDate: req.body.endDate });
		});
	});
});

router.get('/exportYouthReachedRecPDF', checkLogin, function(req, res, next) {
	var addrLine1 = '';
	var addrLine2 = '';

	switch (req.session.centre) {
		case 'Ang Mo Kio':
			addrLine1 = amkCentreAddr_Line1;
			addrLine2 = amkCentreAddr_Line2;
			break;

		case 'Woodlands':
			addrLine1 = woodlandsCentreAddr_Line1;
			addrLine2 = woodlandsCentreAddr_Line2;
			break;

		case 'Geylang':
			addrLine1 = geylangCentreAddr_Line1;
			addrLine2 = geylangCentreAddr_Line2;
			break;

		default:
			console.log('Invalid centre.');
			throw err('Invalid centre.');
	}

	res.render('exportYouthReachedRecPDF', { youthReachedRec: req.session.youthAttendance,
				  																 totalYouthReached: req.session.totalYouthReached,
																					 addrLine1: addrLine1,
																					 addrLine2: addrLine2 });
});

router.get('/manage', checkLogin, function(req, res, next) {
	req.session.action = 'manage';

	var message = req.session.message;
	var manageTab = req.session.manageTab;
	req.session.message = '';

	var youthQuery = 'SELECT y.centre, y.name, y.school, y.nricNum, y.membershipNum, y.gender, y.address, y.mobileNum, y.dateOfBirth, y.dateOfReg, pr.amtPaid AS totalPaid' +
									' FROM Youth y LEFT JOIN (' +
											' SELECT p.youthMembershipNum, p.youthCentre, SUM(p.paymentAmt) as amtPaid' +
											' FROM Payment p' +
											' WHERE YEAR(p.paymentDate) = YEAR(CURDATE())' +
											' AND p.youthCentre = \'' + req.session.centre +
										'\' GROUP BY p.youthMembershipNum) pr' +
									' ON y.membershipNum = pr.youthMembershipNum' +
									' AND y.centre = pr.youthCentre' +
									' WHERE y.centre = \'' + req.session.centre +
								'\' ORDER BY y.membershipNum ASC;';

	var activityQuery = 'SELECT *' + 
										 ' FROM Activity a' +
										 ' WHERE a.centre = \'' + req.session.centre + '\';';
	
	var attendsQuery = 'SELECT *' + 
										' FROM Attends a, Youth y' +
										' WHERE a.activityCentre = \'' + req.session.centre + 
									'\' AND y.membershipNum = a.youthMembershipNum' +
										' AND y.centre = a.activityCentre' +
										' ORDER BY a.youthMembershipNum ASC;';

	var paymentQuery = 'SELECT *' + 
										' FROM Payment p' +
										' WHERE p.youthCentre = \'' + req.session.centre +  
									'\' ORDER BY p.youthMembershipNum, p.paymentDate ASC;';

	var yearOptionsQuery = 'SELECT DISTINCT YEAR(p.paymentDate) as yearOptions' +
												' FROM Payment p' +
												' WHERE p.youthCentre = \'' + req.session.centre + '\';';

	connection.query(youthQuery, function(err, youth, fields) {
		if (err) throw err;

		connection.query(activityQuery, function(err, activity, fields) {
			if (err) throw err;

			connection.query(attendsQuery, function(err, attends, fields) {
				if (err) throw err;

				connection.query(paymentQuery, function(err, payment, fields) {
					if (err) throw err;

					connection.query(yearOptionsQuery, function(err, yearOptions, fields) {
						if (err) throw err;

						res.render('manage', { centre: req.session.centre, 
																	 currAction: req.session.action, 
																	 manageTab: manageTab,
																	 youthData: youth,
																	 activityData: activity,
																	 attendsData: attends,
																	 paymentData: payment,
																	 yearOptions: yearOptions,
																	 message: req.query.msg });
					});
				});
			});
		});
	});
});

router.get('/manageYouth/:category', checkLogin, function(req, res, next) {
	req.session.action = 'manage';

	var memberCat = '';
	var youthQuery = '';
	var message = req.session.message;
	req.session.message = '';

	switch (req.params.category) {
		case 'member':
			memberCat = 'Member';
			req.session.youth.category = 'member';

			youthQuery = 'SELECT m.membershipNum, m.membershipValidity, y.name, y.school, y.nricNum, y.gender, y.address, y.mobileNum, y.parentMobileNum, y.dateOfBirth, y.dateOfReg, y.centre, pr.amtPaid AS totalPaid' +
									' FROM Youth y, Member m' +
									' LEFT JOIN (' +
											' SELECT p.youthNricNum, p.youthCentre, SUM(p.paymentAmt) as amtPaid' +
											' FROM Payment p' +
											' WHERE YEAR(p.paymentDate) = YEAR(CURDATE())' +
											' AND p.youthCentre = \'' + req.session.centre +
										'\' GROUP BY p.youthNricNum) pr' +
									' ON m.youthNricNum = pr.youthNricNum' +
									' AND m.youthCentre = pr.youthCentre' +
									' WHERE m.youthCentre = \'' + req.session.centre +
								'\' AND m.youthCentre = y.centre' +
									' AND m.youthNricNum = y.nricNum' +
									' AND y.dateOfExit IS NULL' +
									' AND y.exitComments IS NULL' +
									' ORDER BY m.membershipNum ASC;';
			break;

		case 'nonmember':
			memberCat = 'Non-Member';
			req.session.youth.category = 'nonmember';

			youthQuery = 'SELECT y.name, y.school, y.nricNum, y.gender, y.address, y.mobileNum, y.parentMobileNum, y.dateOfBirth, y.dateOfReg, y.centre, pr.amtPaid AS totalPaid' +
									' FROM Youth y' +
									' LEFT JOIN (' +
											' SELECT p.youthNricNum, p.youthCentre, SUM(p.paymentAmt) as amtPaid' +
											' FROM Payment p' +
											' WHERE YEAR(p.paymentDate) = YEAR(CURDATE())' +
											' AND p.youthCentre = \'' + req.session.centre +
										'\' GROUP BY p.youthNricNum) pr' +
									' ON y.nricNum = pr.youthNricNum' +
									' AND y.centre = pr.youthCentre' +
									' WHERE y.centre = \'' + req.session.centre +
								'\' AND y.dateOfExit IS NULL' +
									' AND y.exitComments IS NULL' +
									' AND NOT EXISTS (' +
											' SELECT *' +
											' FROM Member m' +
											' WHERE m.youthNricNum = y.nricNum' +
											' AND m.youthCentre = y.centre)' +
									' ORDER BY y.school ASC;';
			break;

		case 'inactive':
			memberCat = 'Inactive';
			req.session.youth.category = 'inactive';

			youthQuery = 'SELECT *' +
									' FROM Youth y' +
									' WHERE y.dateOfExit IS NOT NULL' +
									' AND y.centre = \'' + req.session.centre + '\';';
			break;

		default:
			console.log('Not a valid category.');
			throw err('Invalid youth category.');
	}

	connection.query(youthQuery, function(err, youth, fields) {
		if (err) throw err;

		res.render('manageYouth', { centre: req.session.centre, 
																currAction: req.session.action, 
																memberCat: memberCat,
																youthData: youth,
																message: req.query.msg });
	});
});

router.get('/manageMembership/:year', checkLogin, function(req, res, next) {
	req.session.action = 'manage';

	var message = req.session.message;
	req.session.message = '';
	req.session.year = req.params.year;

	var memberQuery = 'SELECT m.membershipNum, y.name, y.gender, m.youthNricNum, y.school, m.membershipDate, m.membershipValidity, y.centre' +
									 ' FROM Youth y, Member m' +
									 ' WHERE m.youthCentre = \'' + req.session.centre +
								 '\' AND m.youthNricNum = y.nricNum' +
									 ' AND m.youthCentre = y.centre' +
									 ' AND m.membershipValidity = \'' + req.params.year +
								 '\' ORDER BY m.membershipNum ASC;';

	var yearOptionsQuery = 'SELECT DISTINCT m.membershipValidity AS selectedYear' +
												' FROM Member m' +
												' WHERE m.youthCentre = \'' + req.session.centre + '\';';

	connection.query(memberQuery, function(err, member, fields) {
		if (err) throw err;

		connection.query(yearOptionsQuery, function(err, yearOptions, fields) {
			if (err) throw err;

			res.render('manage', { centre: req.session.centre, 
														 currAction: req.session.action, 
														 dbTable: 'Membership',
														 selectedYear: req.params.year,
														 memberData: member,
														 yearOptions: yearOptions,
														 message: req.query.msg });
		});
	});
});

router.get('/manageMentee/:year', checkLogin, function(req, res, next) {
	req.session.action = 'manage';

	var message = req.session.message;
	req.session.message = '';
	req.session.year = req.params.year;

	var menteeQuery = 'SELECT y.name, y.gender, m.youthNricNum, y.school, m.menteeDate, m.menteeValidity, m.myasPreScore, m.myasPostScore, m.myasScoreDate, y.centre' +
									 ' FROM Youth y, Mentee m' +
									 ' WHERE m.youthCentre = \'' + req.session.centre +
								 '\' AND m.youthNricNum = y.nricNum' +
									 ' AND m.youthCentre = y.centre' +
									 ' AND m.menteeValidity = \'' + req.params.year +
								 '\' ORDER BY m.menteeDate ASC;';

	var yearOptionsQuery = 'SELECT DISTINCT m.menteeValidity AS selectedYear' +
												' FROM Mentee m' +
												' WHERE m.youthCentre = \'' + req.session.centre + '\';';

	connection.query(menteeQuery, function(err, mentee, fields) {
		if (err) throw err;

		connection.query(yearOptionsQuery, function(err, yearOptions, fields) {
			if (err) throw err;

			res.render('manage', { centre: req.session.centre, 
														 currAction: req.session.action, 
														 dbTable: 'Mentee',
														 selectedYear: req.params.year,
														 menteeData: mentee,
														 yearOptions: yearOptions,
														 message: req.query.msg });
		});
	});
});

router.get('/managePYDI/:year', checkLogin, function(req, res, next) {
	req.session.action = 'manage';

	var message = req.session.message;
	req.session.message = '';
	req.session.year = req.params.year;

	var pydiQuery = 'SELECT y.name, y.gender, p.youthNricNum, y.school, p.preScore, p.postScore, p.scoreDate, p.scoreValidity, y.centre' +
									 ' FROM Youth y, PYDI p' +
									 ' WHERE p.youthCentre = \'' + req.session.centre +
								 '\' AND p.youthNricNum = y.nricNum' +
									 ' AND p.youthCentre = y.centre' +
									 ' AND p.scoreValidity = \'' + req.params.year +
								 '\' ORDER BY y.school ASC;';

	var yearOptionsQuery = 'SELECT DISTINCT p.scoreValidity AS selectedYear' +
												' FROM PYDI p' +
												' WHERE p.youthCentre = \'' + req.session.centre + '\';';

	connection.query(pydiQuery, function(err, pydi, fields) {
		if (err) throw err;

		connection.query(yearOptionsQuery, function(err, yearOptions, fields) {
			if (err) throw err;

			res.render('manage', { centre: req.session.centre, 
														 currAction: req.session.action, 
														 dbTable: 'PYDI',
														 selectedYear: req.params.year,
														 pydiData: pydi,
														 yearOptions: yearOptions,
														 message: req.query.msg });
		});
	});
});

router.get('/managePayment', checkLogin, function(req, res, next) {
	req.session.action = 'manage';

	var message = req.session.message;
	req.session.message = '';

	var yearOptionsQuery = 'SELECT DISTINCT YEAR(p.paymentDate) AS selectedYear' +
												' FROM Payment p' +
												' WHERE p.youthCentre = \'' + req.session.centre + '\';';

	var nameNricListQuery = 'SELECT y.nricNum, y.name' +
												 ' FROM Youth y' +
												 ' WHERE y.centre = \'' + req.session.centre + '\';';

	connection.query(yearOptionsQuery, function(err, yearOptions, fields) {
		if (err) throw err;

		connection.query(nameNricListQuery, function(err, nameNricList, fields) {
			if (err) throw err;

			var parsedNameNricList = [];

			for (var i = 0; i < nameNricList.length; i++) {
				var memStr = nameNricList[i].nricNum + ' ' + nameNricList[i].name;
				parsedNameNricList.push(memStr);
			}

			res.render('managePayment', { centre: req.session.centre, 
																		currAction: req.session.action, 
																		paymentData: [],
																		yearOptions: yearOptions,
																		isQueried: false,
																		youthNricName: '',
																		message: req.query.msg,
	  																nameNricList: parsedNameNricList });
		});
	});
});

router.post('/managePayment', checkLogin, function(req, res, next) {
	req.session.action = 'manage';

	var message = req.session.message;
	req.session.message = '';

	var paymentQuery = 'SELECT p.paymentDate, y.name, y.gender, p.youthNricNum, y.school, p.paymentAmt, p.youthCentre' +
										' FROM Payment p, Youth y' +
										' WHERE p.youthCentre = \'' + req.session.centre +
									'\' AND p.youthNricNum = \'' + req.body.name.substr(0, 9).toUpperCase() +
									'\' AND p.youthCentre = y.centre' +
										' AND p.youthNricNum = y.nricNum' +
										' AND YEAR(p.paymentDate) = \'' + req.body.paymentYr + '\';';

	var yearOptionsQuery = 'SELECT DISTINCT YEAR(p.paymentDate) AS selectedYear' +
												' FROM Payment p' +
												' WHERE p.youthCentre = \'' + req.session.centre + '\';';

	var nameNricListQuery = 'SELECT y.nricNum, y.name' +
												 ' FROM Youth y' +
												 ' WHERE y.centre = \'' + req.session.centre + '\';';

	connection.query(paymentQuery, function(err, payment, fields) {
		if (err) throw err;

		connection.query(yearOptionsQuery, function(err, yearOptions, fields) {
			if (err) throw err;

			connection.query(nameNricListQuery, function(err, nameNricList, fields) {
				if (err) throw err;

				var parsedNameNricList = [];

				for (var i = 0; i < nameNricList.length; i++) {
					var memStr = nameNricList[i].nricNum + ' ' + nameNricList[i].name;
					parsedNameNricList.push(memStr);
				}

				res.render('managePayment', { centre: req.session.centre, 
																			currAction: req.session.action, 
																			paymentData: payment,
																			yearOptions: yearOptions,
																			isQueried: true,
																			youthNricName: req.body.name,
																			youthName: req.body.name.substring(9),
																			paymentYear: req.body.paymentYr,
																			message: req.query.msg,
	  																	nameNricList: parsedNameNricList });
			});
		});
	});
});

router.get('/manageActivities/:year', checkLogin, function(req, res, next) {
	req.session.action = 'manage';

	var message = req.session.message;
	req.session.message = '';
	req.session.year = req.params.year;

	var activityQuery = 'SELECT *' +
										 ' FROM Activity a' +
										 ' WHERE a.centre = \'' + req.session.centre +
									 '\' AND YEAR(a.activityDate) = \'' + req.params.year +
									 '\' ORDER BY a.activityDate DESC;';

	var yearOptionsQuery = 'SELECT DISTINCT YEAR(a.activityDate) AS selectedYear' +
												' FROM Activity a' +
												' WHERE a.centre = \'' + req.session.centre + '\';';

	connection.query(activityQuery, function(err, activity, fields) {
		if (err) throw err;

		connection.query(yearOptionsQuery, function(err, yearOptions, fields) {
			if (err) throw err;

			res.render('manage', { centre: req.session.centre, 
														 currAction: req.session.action, 
														 dbTable: 'Activities',
														 selectedYear: req.params.year,
														 activitiesData: activity,
														 yearOptions: yearOptions,
														 message: req.query.msg });
		});
	});
});

router.get('/manageAttendance/:year', checkLogin, function(req, res, next) {
	req.session.action = 'manage';

	var message = req.session.message;
	req.session.message = '';
	req.session.year = req.params.year;

	var attendsQuery = 'SELECT a.activityDate, y.name, y.gender, a.youthNricNum, y.school, a.activityTopic, a.startTime, a.endTime, a.activityCentre' +
										' FROM Attends a, Youth y' +
										' WHERE a.activityCentre = \'' + req.session.centre +
									'\' AND YEAR(a.activityDate) = \'' + req.params.year +
									'\' AND a.youthCentre = y.centre' +
										' AND a.youthNricNum = y.nricNum' +
										' ORDER BY a.activityDate DESC, a.activityTopic, y.school ASC;';

	var yearOptionsQuery = 'SELECT DISTINCT YEAR(a.activityDate) AS selectedYear' +
												' FROM Attends a' +
												' WHERE a.activityCentre = \'' + req.session.centre + '\';';

	connection.query(attendsQuery, function(err, attendance, fields) {
		if (err) throw err;

		connection.query(yearOptionsQuery, function(err, yearOptions, fields) {
			if (err) throw err;

			res.render('manage', { centre: req.session.centre, 
														 currAction: req.session.action, 
														 dbTable: 'Attendance',
														 selectedYear: req.params.year,
														 attendanceData: attendance,
														 yearOptions: yearOptions,
														 message: req.query.msg });
		});
	});
});

router.get('/edit/Youth/:nricNum/:centre', checkLogin, function(req, res, next) {
	var youthQuery = 'SELECT * ' + 
									 'FROM Youth y ' + 
									 'WHERE y.nricNum = \'' + req.params.nricNum + 
								'\' AND y.centre = \'' + req.params.centre + '\';';

	var isThereMenteeRecordsQuery = 'SELECT (' + 
																		'EXISTS (' + 
																			'SELECT * ' + 
																        'FROM Mentee m ' + 
																        'WHERE m.youthNricNum = \'' + req.params.nricNum + 
															       '\' AND m.youthCentre = \'' + req.params.centre + 
															       '\' AND m.menteeValidity = YEAR(CURDATE()))) AS isThereMenteeRecords;';

	connection.query(isThereMenteeRecordsQuery, function(err, isThereMenteeRecords, fields) {
	  if (err) throw err;

		connection.query(youthQuery, function(err, youth, fields) {
		  if (err) throw err;

		  req.session.youth.action = 'Edit';
		  req.session.youth.name = youth[0].name;
	  	req.session.youth.school = youth[0].school;
	  	req.session.youth.nricNum = youth[0].nricNum;
		  req.session.youth.address = youth[0].address;
	  	req.session.youth.gender = youth[0].gender;
	  	req.session.youth.mobileNum = youth[0].mobileNum;
	  	req.session.youth.parentMobileNum = youth[0].parentMobileNum;
	  	req.session.youth.dateOfBirth = youth[0].dateOfBirth;
	  	req.session.youth.membershipFeePaid = 0.00;
	  	req.session.youth.isMentee = (isThereMenteeRecords[0].isThereMenteeRecords ? true : false);

	  	res.render('youth', { centre: req.session.centre, 
		  											currAction: req.session.action, 
		  											formTitle:  'Edit Youth Record',
		  											formAction: '/update/Youth/' + youth[0].nricNum + '/' + req.session.centre,
		  											youth: req.session.youth });
		});
	});
});

router.post('/update/Youth/:nricNum/:centre', checkLogin, function(req, res, next) {

	var insertPaymentRecordQuery = 'INSERT INTO Payment (youthNricNum, ' + 
																											'youthCentre, ' +
																											'paymentDate, ' + 
																											'paymentAmt) ' + 
																			 'VALUES (\'' + req.params.nricNum + '\', \'' +
																											req.session.centre + '\', ' +
																											'CURDATE(), ' +
																											req.body.membershipFeePaid + ');';

	var insertMenteeRecordQuery = 'INSERT INTO Mentee (youthNricNum, ' + 
																										'youthCentre, ' +
																										'menteeDate, ' + 
																										'menteeValidity, ' + 
																										'myasPreScore, ' + 
																										'myasPostScore, ' + 
																										'myasScoreDate) ' + 
																		 'VALUES (\'' + req.params.nricNum + '\', \'' +
																										req.session.centre + '\', ' +
																										'CURDATE(), ' +
																										'YEAR(CURDATE()), ' + 
																										'NULL, NULL, CURDATE());';

	var isThereMenteeRecordsQuery = 'SELECT (' + 
																		'EXISTS (' + 
																			'SELECT * ' + 
																        'FROM Mentee m ' + 
																        'WHERE m.youthNricNum = \'' + req.params.nricNum + 
															       '\' AND m.youthCentre = \'' + req.params.centre + 
															       '\' AND m.menteeValidity = YEAR(CURDATE()))) AS isThereMenteeRecords;';

	var updateYouthQuery = 'UPDATE Youth SET name = \'' + req.body.name + 
													 '\', school = \'' + req.body.school + 
													 '\', gender = \'' + req.body.gender +
													 '\', address = \'' + req.body.address +
													 '\', mobileNum = ' + req.body.mobileNum +
													 	 ', parentMobileNum = ' + (req.body.parentMobileNum ? req.body.parentMobileNum : 'NULL') +
														 ', dateOfBirth = \'' + req.body.dateOfBirth + 
													 '\', dateOfExit = ' + (req.body.exitToday ? 'CURDATE()' : 'NULL') +
												 		 ', exitComments = ' + (req.body.exitToday ? '\'' + req.body.exitReasons + '\'' : 'NULL') +
										 		' WHERE nricNum = \'' + req.params.nricNum + 
											'\' AND centre = \'' + req.session.centre + '\';';

	if (req.body.membershipFeePaid > 0) {
		connection.query(insertPaymentRecordQuery, function(err, rows, fields) {
			if (err) {
				switch (err.code) {
					case 'ER_DUP_ENTRY':
						req.session.youth.errorMsg = 'Payment installment record already entered for today.';
	  				break;
				}

				res.redirect('/edit/Youth/' + req.params.nricNum + '/' + req.params.centre);

			} else {
				connection.query(isThereMenteeRecordsQuery, function(err, isThereMenteeRecords, fields) {
	  			if (err) throw err;

	  			if (!isThereMenteeRecords[0].isThereMenteeRecords && req.body.menteeToday) {
	  				connection.query(insertMenteeRecordQuery, function(err, rows, fields) {
	  					if (err) throw err;

	  					connection.query(updateYouthQuery, function(err, rows, fields) {
							  if (err) {
							  	switch (err.code) {
							  		case 'ER_SIGNAL_EXCEPTION':
							  			req.session.youth.errorMsg = err.message.substring(21);
							  			break;

						  			case 'ER_DUP_ENTRY':
						  				if (regExpYouthPriKey.test(err.message)) {
						  					req.session.youth.errorMsg = 'Specified MEMBERSHIP NUMBER has already been taken.';
						  				} else if (regExpYouthMobile.test(err.message)) {
						  					req.session.youth.errorMsg = 'Specified MOBILE NUMBER has already been taken.';
						  				} else if (regExpYouthNRIC.test(err.message)) {
						  					req.session.youth.errorMsg = 'Specified NRIC NUMBER is already registered.';
						  				}
						  				break;
							  	}

							  	res.redirect('/edit/Youth/' + req.params.nricNum + '/' + req.params.centre);
							  
							  } else {

							  	var category = req.session.youth.category;
							  	for (item in req.session.youth) {
							  		req.session.youth[item] = '';
							  	}
							  	var string = encodeURIComponent(req.params.nricNum + ' ' + req.body.name + ' successfully updated!');
						  		res.redirect('/manageYouth/' + category + '?msg=' + string);
							  }
							});
	  				});
	  			} else {
	  				connection.query(updateYouthQuery, function(err, rows, fields) {
						  if (err) {
						  	switch (err.code) {
						  		case 'ER_SIGNAL_EXCEPTION':
						  			req.session.youth.errorMsg = err.message.substring(21);
						  			break;

					  			case 'ER_DUP_ENTRY':
					  				if (regExpYouthPriKey.test(err.message)) {
					  					req.session.youth.errorMsg = 'Specified MEMBERSHIP NUMBER has already been taken.';
					  				} else if (regExpYouthMobile.test(err.message)) {
					  					req.session.youth.errorMsg = 'Specified MOBILE NUMBER has already been taken.';
					  				} else if (regExpYouthNRIC.test(err.message)) {
					  					req.session.youth.errorMsg = 'Specified NRIC NUMBER is already registered.';
					  				}
					  				break;
						  	}

						  	res.redirect('/edit/Youth/' + req.params.nricNum + '/' + req.params.centre);
						  
						  } else {

						  	var category = req.session.youth.category;
						  	for (item in req.session.youth) {
						  		req.session.youth[item] = '';
						  	}
						  	var string = encodeURIComponent(req.params.nricNum + ' ' + req.body.name + ' successfully updated!');
					  		res.redirect('/manageYouth/' + category + '?msg=' + string);
						  }
						});
	  			}
				});
			}
		});

	} else {
		
		connection.query(isThereMenteeRecordsQuery, function(err, isThereMenteeRecords, fields) {
			if (err) throw err;

			if (!isThereMenteeRecords[0].isThereMenteeRecords && req.body.menteeToday) {
				connection.query(insertMenteeRecordQuery, function(err, rows, fields) {
					if (err) throw err;

					connection.query(updateYouthQuery, function(err, rows, fields) {
					  if (err) {
					  	switch (err.code) {
					  		case 'ER_SIGNAL_EXCEPTION':
					  			req.session.youth.errorMsg = err.message.substring(21);
					  			break;

				  			case 'ER_DUP_ENTRY':
				  				if (regExpYouthPriKey.test(err.message)) {
				  					req.session.youth.errorMsg = 'Specified MEMBERSHIP NUMBER has already been taken.';
				  				} else if (regExpYouthMobile.test(err.message)) {
				  					req.session.youth.errorMsg = 'Specified MOBILE NUMBER has already been taken.';
				  				} else if (regExpYouthNRIC.test(err.message)) {
				  					req.session.youth.errorMsg = 'Specified NRIC NUMBER is already registered.';
				  				}
				  				break;
					  	}

					  	res.redirect('/edit/Youth/' + req.params.nricNum + '/' + req.params.centre);
					  
					  } else {

					  	var category = req.session.youth.category;
					  	for (item in req.session.youth) {
					  		req.session.youth[item] = '';
					  	}
					  	var string = encodeURIComponent(req.params.nricNum + ' ' + req.body.name + ' successfully updated!');
				  		res.redirect('/manageYouth/' + category + '?msg=' + string);
					  }
					});
				});
			} else {
				connection.query(updateYouthQuery, function(err, rows, fields) {
				  if (err) {
				  	switch (err.code) {
				  		case 'ER_SIGNAL_EXCEPTION':
				  			req.session.youth.errorMsg = err.message.substring(21);
				  			break;

			  			case 'ER_DUP_ENTRY':
			  				if (regExpYouthPriKey.test(err.message)) {
			  					req.session.youth.errorMsg = 'Specified MEMBERSHIP NUMBER has already been taken.';
			  				} else if (regExpYouthMobile.test(err.message)) {
			  					req.session.youth.errorMsg = 'Specified MOBILE NUMBER has already been taken.';
			  				} else if (regExpYouthNRIC.test(err.message)) {
			  					req.session.youth.errorMsg = 'Specified NRIC NUMBER is already registered.';
			  				}
			  				break;

			  			default:
			  				console.log(err);
				  	}

				  	res.redirect('/edit/Youth/' + req.params.nricNum + '/' + req.params.centre);
				  
				  } else {

				  	var category = req.session.youth.category;
				  	for (item in req.session.youth) {
				  		req.session.youth[item] = '';
				  	}
				  	var string = encodeURIComponent(req.params.nricNum + ' ' + req.body.name + ' successfully updated!');
			  		res.redirect('/manageYouth/' + category + '?msg=' + string);
				  }
				});
			}
		});
	}
});

router.post('/delete/Youth/:nricNum/:centre', checkLogin, function(req, res, next) {
	var query = 'DELETE FROM Youth' + 
						 ' WHERE nricNum = \'' + req.params.nricNum + 
					 '\' AND centre = \'' + req.params.centre + '\';';

	connection.query(query, function(err, results, fields) {
	  if (err) throw err;

	  var category = req.session.youth.category;
  	for (item in req.session.youth) {
  		req.session.youth[item] = '';
  	}

	  var string = encodeURIComponent('Youth record successfully deleted!');
  	res.redirect('/manageYouth/' + category + '?msg=' + string);
	});
});

router.post('/delete/Member/:nricNum/:centre/:membershipNum/:year', checkLogin, function(req, res, next) {
	var query = 'DELETE FROM Member' + 
						 ' WHERE youthNricNum = \'' + req.params.nricNum + 
					 '\' AND youthCentre = \'' + req.params.centre + 
					 '\' AND membershipNum = ' + req.params.membershipNum +
						 ' AND membershipValidity = \'' + req.params.year + '\';';

	connection.query(query, function(err, results, fields) {
	  if (err) throw err;

	  var string = encodeURIComponent('Membership record successfully deleted!');
  	res.redirect('/manageMembership/' + req.session.year + '?msg=' + string);
	});
});

router.post('/delete/Payment/:youthNricNum/:youthCentre/:paymentDate', checkLogin, function(req, res, next) {

	var delPaymentRecordQuery = 'DELETE FROM Payment' + 
														 ' WHERE youthNricNum = \'' + req.params.youthNricNum + 
													 '\' AND youthCentre = \'' + req.params.youthCentre + 
													 '\' AND paymentDate = \'' + req.params.paymentDate + '\';';

	connection.query(delPaymentRecordQuery, function(err, results, fields) {
	  if (err) throw err;

	  var string = encodeURIComponent('Payment record successfully deleted!');
  	res.redirect('/managePayment?msg=' + string);
	});
});

router.post('/delete/Activity/:centre/:topic/:date', checkLogin, function(req, res, next) {
	var query = 'DELETE FROM Activity' + 
						 ' WHERE centre = \'' + req.params.centre + 
					 '\' AND topic = \'' + req.params.topic + 
					 '\' AND activityDate = \'' + req.params.date + '\';';

	connection.query(query, function(err, results, fields) {
	  if (err) throw err;

		var string = encodeURIComponent('Activity record successfully deleted!');
  	res.redirect('/manageActivities/' + req.session.year + '?msg=' + string);
	});
});

router.post('/delete/Attends/:youthNricNum/:activityCentre/:activityTopic/:activityDate', checkLogin, function(req, res, next) {
	var query = 'DELETE FROM Attends' + 
						 ' WHERE youthNricNum = \'' + req.params.youthNricNum + 
					 '\' AND youthCentre = \'' + req.params.activityCentre + 
					 '\' AND activityCentre = \'' + req.params.activityCentre + 
					 '\' AND activityTopic = \'' + req.params.activityTopic +
					 '\' AND activityDate = \'' + req.params.activityDate + '\';';

	connection.query(query, function(err, results, fields) {
	  if (err) throw err;

	  var string = encodeURIComponent('Attendance record successfully deleted!');
  	res.redirect('/manageAttendance/' + req.session.year + '?msg=' + string);
	});
});

router.get('/edit/Mentee/:youthNricNum/:centre/:menteeValidity', checkLogin, function(req, res, next) {
	var menteeQuery = 'SELECT m.myasPreScore, m.myasPostScore ' + 
									  'FROM Mentee m ' + 
									  'WHERE m.youthNricNum = \'' + req.params.youthNricNum + 
								 '\' AND m.youthCentre = \'' + req.params.centre + 
								 '\' AND m.menteeValidity = \'' + req.params.menteeValidity + '\';';

	connection.query(menteeQuery, function(err, mentee, fields) {
	  if (err) throw err;

	  req.session.mentee.myasPreScore = mentee[0].myasPreScore;
	  req.session.mentee.myasPostScore = mentee[0].myasPostScore;

  	res.render('mentee', { centre: req.session.centre, 
	  											 currAction: req.session.action, 
	  											 formAction: '/update/Mentee/' + req.params.youthNricNum + '/' + req.session.centre + '/' + req.params.menteeValidity,
	  											 mentee: req.session.mentee });
	});
});

router.post('/update/Mentee/:youthNricNum/:centre/:menteeValidity', checkLogin, function(req, res, next) {
	var updateMenteeQuery = 'UPDATE Mentee SET myasPreScore = ' + (req.body.myasPreScore ? req.body.myasPreScore : 'NULL') + 
																					', myasPostScore = ' + (req.body.myasPostScore ? req.body.myasPostScore : 'NULL') + 
																					', myasScoreDate = CURDATE()' + 
										 		 ' WHERE youthNricNum = \'' + req.params.youthNricNum + 
											 '\' AND youthCentre = \'' + req.params.centre + 
											 '\' AND menteeValidity = \'' + req.params.menteeValidity + '\';';

	connection.query(updateMenteeQuery, function(err, rows, fields) {
		if (err) throw err;

		var d = new Date();

		for (item in req.session.mentee) {
			req.session.mentee[item] = '';
		}

		var string = encodeURIComponent('Mentee record successfully updated!');
		res.redirect('/manageMentee/' + d.getFullYear() + '?msg=' + string);
	});
});

router.post('/delete/Mentee/:youthNricNum/:centre/:menteeValidity', checkLogin, function(req, res, next) {
	var query = 'DELETE FROM Mentee' + 
						 ' WHERE youthCentre = \'' + req.params.centre + 
					 '\' AND youthNricNum = \'' + req.params.youthNricNum + 
					 '\' AND menteeValidity = \'' + req.params.menteeValidity + '\';';

	connection.query(query, function(err, results, fields) {
	  if (err) throw err;

		var string = encodeURIComponent('Mentee record successfully deleted!');
  	res.redirect('/manageMentee/' + req.session.year + '?msg=' + string);
	});
});

router.get('/edit/PYDI/:youthNricNum/:centre/:scoreValidity', checkLogin, function(req, res, next) {
	var pydiQuery = 'SELECT p.preScore, p.postScore ' + 
								  'FROM PYDI p ' + 
								  'WHERE p.youthNricNum = \'' + req.params.youthNricNum + 
							 '\' AND p.youthCentre = \'' + req.params.centre + 
							 '\' AND p.scoreValidity = \'' + req.params.scoreValidity + '\';';

	connection.query(pydiQuery, function(err, pydi, fields) {
	  if (err) throw err;

	  req.session.pydi.pydiPreScore = pydi[0].preScore;
	  req.session.pydi.pydiPostScore = pydi[0].postScore;

  	res.render('pydi', { centre: req.session.centre, 
  											 currAction: req.session.action, 
  											 formAction: '/update/PYDI/' + req.params.youthNricNum + '/' + req.session.centre + '/' + req.params.scoreValidity,
  											 pydi: req.session.pydi });
	});
});

router.post('/update/PYDI/:youthNricNum/:centre/:scoreValidity', checkLogin, function(req, res, next) {
	var updatePYDIQuery = 'UPDATE PYDI SET preScore = ' + (req.body.pydiPreScore ? req.body.pydiPreScore : 'NULL') + 
																			', postScore = ' + (req.body.pydiPostScore ? req.body.pydiPostScore : 'NULL') + 
																			', scoreDate = CURDATE()' +
										 		 ' WHERE youthNricNum = \'' + req.params.youthNricNum + 
											 '\' AND youthCentre = \'' + req.params.centre + 
											 '\' AND scoreValidity = \'' + req.params.scoreValidity + '\';';

	connection.query(updatePYDIQuery, function(err, rows, fields) {
		if (err) throw err;

		var d = new Date();

		for (item in req.session.pydi) {
			req.session.pydi[item] = '';
		}

		var string = encodeURIComponent('PYDI record successfully updated!');
		res.redirect('/managePYDI/' + d.getFullYear() + '?msg=' + string);
	});
});

module.exports = router;
