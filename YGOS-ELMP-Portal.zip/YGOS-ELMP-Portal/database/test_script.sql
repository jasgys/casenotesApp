INSERT INTO Youth (name, school, membershipNum, gender, mobileNum, dateOfBirth, dateOfReg)
	VALUES ('Sally', 'Yu Hua Secondary School', 834, 'F', 87352849, '1991-09-19', CURDATE());

INSERT INTO Activity (activityDate, centre, topic)
	VALUES ('2016-01-17','woodlands','Insanity');
    
INSERT INTO Attends (startTime, endTime, youthMembershipNum, activityDate, activityCentre, activityTopic)
	VALUES ('22:00:00', '23:00:00', 834, '2016-01-13', 'Woodlands', 'BGR');
    
UPDATE Youth SET name = 'Danny'
	WHERE membershipNum = 222;
    
SET time_zone = 'Asia/Singapore';
    
SELECT CURDATE();
SELECT CURTIME();

SELECT * FROM Activity;
SELECT * FROM Youth;
SELECT * FROM Attends;
SELECT * FROM Users;
SELECT * FROM Posts; 

SELECT * FROM Users u WHERE u.userID = 'ygosAMK';

SELECT NOW();

SELECT (EXISTS (
		SELECT * FROM Attends a 
		WHERE a.youthMembershipNum = 561 
        AND a.activityDate = CURDATE() 
        AND a.activityCentre = 'Ang Mo Kio'
        AND a.youthCentre = 'Ang Mo Kio'
        AND a.endTime IS NOT NULL));

SELECT CURTIME();

SELECT (TIME('15:15') < SUBTIME(CURTIME(), '00:15:00'));

SELECT (NOT EXISTS (
	SELECT * FROM Youth y
	WHERE y.membershipNum = 444
	AND y.centre = 'Ang Mo Kio'));

UPDATE Attends SET endTime = '23:23' 
	WHERE youthMembershipNum = 444 
    AND youthCentre = 'Ang Mo Kio' 
    AND activityDate = CURDATE() 
    AND activityCentre = 'Ang Mo Kio' 
    AND endTime IS NULL;

UPDATE Attends 
	SET endTime = NULL 
    WHERE youthMembershipNum = 561 
    AND activityDate = CURDATE() 
    AND activityCentre = 'Ang Mo Kio' 
    AND endTime IS NOT NULL;
    
SELECT * FROM Attends a
	WHERE a.youthMembershipNum = 561
    AND a.activityDate = CURDATE()
    AND a.activityCentre = 'Ang Mo Kio'
    AND a.endTime = NULL;

UPDATE Attends
	SET endTime = '23:30'
    WHERE youthMembershipNum = 561
    AND youthCentre = 'Ang Mo Kio'
    AND activityDate = CURDATE()
    AND activityCentre = 'Ang Mo Kio'
    AND activityTopic = 'Sports';


SELECT EXISTS(
	SELECT * FROM Activity a
    WHERE a.centre = 'Woodlands'
    AND a.topic <> 'Sports'
    AND a.activityDate = CURDATE()) as isThereDropIn;

INSERT INTO Youth (name, school, nricNum, membershipNum, gender, mobileNum, dateOfBirth, dateOfReg, centre) 
	VALUES ('rrr', 'rrr', UCASE('S9274837R'), 333, 'M', 98269030, '2016-02-25', CURDATE(), 'Ang Mo Kio');

SELECT * FROM Attends a
	WHERE a.youthMembershipNum = 834
    AND a.activityCentre = 'Woodlands'
    AND MONTHNAME(a.activityDate) = 'January'
    AND YEAR(a.activityDate) = '2016'
    ORDER BY a.activityDate ASC;

SELECT * FROM Attends a, Youth y
	WHERE a.activityCentre = 'Woodlands'
    AND y.membershipNum = a.youthMembershipNum
    AND y.centre = a.activityCentre
    ORDER BY a.youthMembershipNum ASC;

SELECT * FROM Attends a WHERE a.youthMembershipNum = 561 ORDER BY a.activityDate ASC;

SELECT * FROM Youth y, Attends a
	WHERE y.membershipNum = a.youthMembershipNum
    AND y.membershipNum = 222
    AND a.activityCentre = 'geylang'
    AND MONTHNAME(a.activityDate) = 'January'
    AND YEAR(a.activityDate) = '2016';

SELECT * FROM Attends a
	WHERE a.activityDate > '2016-01-25'
    AND a.activityDate < '2016-01-31';
    
SELECT DISTINCT YEAR(a.activityDate) AS year FROM Attends a;
    
SELECT y.name, y.school, a.activityTopic, a.youthMembershipNum, a.startTime, a.endTime
	FROM Youth y, Attends a
    WHERE y.membershipNum = a.youthMembershipNum
    AND a.activityDate = '2016-01-29';
    
DELETE FROM Activity WHERE centre = 'Ang Mo Kio' AND topic = 'BGR' AND activityDate = '8-2-2016';

DELETE FROM Activity
	WHERE centre = 'woodlands'
    AND topic = 'BGR'
    AND activityDate = '2016-01-13';
    
DELETE FROM Attends;
DELETE FROM Activity;
DELETE FROM Youth;
    
DELETE FROM Youth
	WHERE membershipNum = 222;
    
DELETE FROM Attends
	WHERE youthMembershipNum = 834;
    
SELECT * FROM Activity a GROUP BY a.centre;

# Populate Users Table
INSERT INTO Users (userID, md5Hash, centre)
	VALUES ('ygosAMK', 'b0af0970a01f2c13bc65d422d2e05eb6', 'Ang Mo Kio');
    
INSERT INTO Users (userID, md5Hash, centre)
	VALUES ('ygosGeylang', 'd99b91160da4a4b0af71f2ef7f86fcca', 'Geylang');
    
INSERT INTO Users (userID, md5Hash, centre)
	VALUES ('ygosWoodlands', '109b7fe5cb2621f6c39ce80df6cf6ad6', 'Woodlands');

# Populate Youth table
INSERT INTO Youth (name, school, nricNum, membershipNum, gender, mobileNum, dateOfBirth, dateOfReg, centre)
	VALUES ('Sandra', 'New Town Secondary School', UCASE('s9126472r'), 222, 'F', 92748375, '1992-11-12', CURDATE(), 'Geylang');
    
INSERT INTO Youth (name, school, nricNum, membershipNum, gender, mobileNum, dateOfBirth, dateOfReg, centre)
	VALUES ('John Tan', 'Presbyterian High School', UCASE('s9876543f'), 434, 'M', 82546372, '1994-08-24', CURDATE(), 'Ang Mo Kio');
    
INSERT INTO Youth (name, school, nricNum, membershipNum, gender, mobileNum, dateOfBirth, dateOfReg, centre)
	VALUES ('Lee Chi Cheng Daniel', 'Hwa Chong Institution', UCASE('s9114755f'), 561, 'M', 98269030, '1991-04-27', CURDATE(), 'Ang Mo Kio');
    
INSERT INTO Youth (name, school, nricNum, membershipNum, gender, mobileNum, dateOfBirth, dateOfReg, centre)
	VALUES ('Sharon', 'Tao Nan Secondary School', UCASE('s9326574f'), 787, 'F', 92637482, '1997-06-27', CURDATE(), 'Woodlands');
    
INSERT INTO Youth (name, school, nricNum, membershipNum, gender, mobileNum, dateOfBirth, dateOfReg, centre)
	VALUES ('Sally', 'Yu Hua Secondary School', UCASE('s9624745f'), 834, 'F', 87352849, '1991-09-19', CURDATE(), 'Woodlands');
    
# Populate Activity table
INSERT INTO Activity (activityDate, centre, topic)
	VALUES (CURDATE(),'Ang Mo Kio','BGR');
    
INSERT INTO Activity (activityDate, centre, topic)
	VALUES (CURDATE(),'Ang Mo Kio','Sports');
    
INSERT INTO Activity (activityDate, centre, topic)
	VALUES (CURDATE(),'Geylang','Depression');
    
INSERT INTO Activity (activityDate, centre, topic)
	VALUES (CURDATE(),'Geylang','Sports');
    
INSERT INTO Activity (activityDate, centre, topic)
	VALUES (CURDATE(),'Woodlands','Finance');
    
INSERT INTO Activity (activityDate, centre, topic)
	VALUES (CURDATE(),'Woodlands','Sports');