DROP TRIGGER valid_Attendance;
-- DROP TRIGGER valid_Attendance_Update;
DROP TRIGGER valid_Activity;
DROP TRIGGER check_Member_Status;
DROP TRIGGER valid_Youth;

DROP TABLE Attends;
DROP TABLE Activity;
DROP TABLE Payment;
DROP TABLE Member;
DROP TABLE Mentee;
DROP TABLE PYDI;
DROP TABLE Youth;
DROP TABLE Users;