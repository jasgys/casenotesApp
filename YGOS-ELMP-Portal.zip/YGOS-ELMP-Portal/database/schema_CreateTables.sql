CREATE TABLE Youth (
	name VARCHAR(255) NOT NULL,
	school VARCHAR(255) NOT NULL,
	nricNum CHAR(9) NOT NULL UNIQUE,
	gender CHAR(1) NOT NULL,
    address VARCHAR(255) NOT NULL,
	mobileNum INT NOT NULL UNIQUE,
    parentMobileNum INT,
	dateOfBirth DATE NOT NULL,
	dateOfReg DATE NOT NULL,
    dateOfExit DATE,
    exitComments VARCHAR(255),
	centre VARCHAR(10),

	PRIMARY KEY (nricNum, centre)
);

delimiter //
CREATE TRIGGER valid_Youth
	BEFORE
		INSERT 
	ON Youth FOR EACH ROW
BEGIN
	IF NEW.gender NOT IN ('M', 'F') THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid Gender.';
	END IF;

	IF NEW.mobileNum > 99499999 OR (NEW.mobileNum < 80000000 AND NEW.mobileNum > 69999999) OR NEW.mobileNum < 60000000 THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid Mobile Phone Number.';
	END IF;
    
    IF NEW.parentMobileNum > 99499999 OR (NEW.parentMobileNum < 80000000 AND NEW.parentMobileNum > 69999999) OR NEW.parentMobileNum < 60000000 THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid Parent/Guardian Mobile Phone Number.';
	END IF;

	IF NEW.dateOfReg < CURDATE() THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'REGISTRATION DATE cannot be earlier than current date.';
	END IF;
    
	IF NEW.centre NOT IN ('Geylang', 'Ang Mo Kio', 'Woodlands') THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid YGOS Centre.';
	END IF;
    
	IF NOT(NEW.nricNum REGEXP '[GST][0123456789]{7}[ABCDEFGHIJKLMNOPQRSTUVWXYZ]') THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid NRIC number.';
	END IF;
END;//
delimiter ;

CREATE TABLE Payment (
	youthNricNum CHAR(9),
	youthCentre CHAR(10),
	paymentDate DATE,
	paymentAmt DECIMAL(3,2) NOT NULL,

	PRIMARY KEY (youthNricNum, youthCentre, paymentDate),

	FOREIGN KEY (youthNricNum, youthCentre)
		REFERENCES Youth(nricNum, centre)
		ON DELETE CASCADE
);

delimiter //
CREATE TRIGGER check_Member_Status
	AFTER
		INSERT 
	ON Payment FOR EACH ROW
BEGIN
	DECLARE totalAmtPaid DECIMAL(3,2);
    DECLARE nextAvailableMembershipNum INT;
    
    SET totalAmtPaid = (
		SELECT SUM(p.paymentAmt)
        FROM Payment p
        WHERE p.youthNricNum = NEW.youthNricNum
        AND p.youthCentre = NEW.youthCentre
        AND YEAR(p.paymentDate) = YEAR(NEW.paymentDate)
    );
    
    SET nextAvailableMembershipNum = (
		SELECT MAX(m.membershipNum)
        FROM Member m
        WHERE m.membershipValidity = YEAR(CURDATE())
        AND m.youthCentre = NEW.youthCentre
    );
    
    IF nextAvailableMembershipNum IS NULL THEN
		SET nextAvailableMembershipNum = 1;
	ELSE
		SET nextAvailableMembershipNum = nextAvailableMembershipNum + 1;
	END IF;

	IF totalAmtPaid >= 5.00 THEN
		INSERT INTO Member (youthNricNum, youthCentre, membershipNum, membershipDate, membershipValidity)
			VALUES (NEW.youthNricNum, NEW.youthCentre, nextAvailableMembershipNum, CURDATE(), YEAR(CURDATE()));
	END IF;
END;//
delimiter ;

CREATE TABLE Member (
	youthNricNum CHAR(9),
    youthCentre CHAR(10),
    membershipNum INT NOT NULL,
    membershipDate DATE NOT NULL,
    membershipValidity YEAR(4) NOT NULL,
    
    PRIMARY KEY (youthNricNum, youthCentre, membershipNum, membershipValidity),
    
    FOREIGN KEY (youthNricNum, youthCentre)
		REFERENCES Youth(nricNum, centre)
		ON DELETE CASCADE
);

CREATE TABLE Mentee (
	youthNricNum CHAR(9),
    youthCentre CHAR(10),
    myasPreScore INT,
    myasPostScore INT,
    myasScoreDate DATE,
    menteeDate DATE NOT NULL,
    menteeValidity YEAR(4) NOT NULL,
    
    PRIMARY KEY (youthNricNum, youthCentre, menteeValidity),
    
    FOREIGN KEY (youthNricNum, youthCentre)
		REFERENCES Youth(nricNum, centre)
		ON DELETE CASCADE
);

CREATE TABLE PYDI (
	youthNricNum CHAR(9),
    youthCentre CHAR(10),
    preScore INT,
    postScore INT,
    scoreDate DATE,
    scoreValidity YEAR(4) NOT NULL,
    
    PRIMARY KEY (youthNricNum, youthCentre, scoreValidity),
    
    FOREIGN KEY (youthNricNum, youthCentre)
		REFERENCES Youth(nricNum, centre)
		ON DELETE CASCADE
);

CREATE TABLE Activity (
	activityDate DATE NOT NULL,
	centre VARCHAR(10) NOT NULL,
	topic VARCHAR(255),

	PRIMARY KEY (activityDate, centre, topic)
);

delimiter //
CREATE TRIGGER valid_Activity
	BEFORE
		INSERT
	ON Activity FOR EACH ROW
BEGIN
-- 	IF NEW.activityDate < CURDATE() THEN
-- 		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ACTIVITY DATE cannot be earlier than current date.';
-- 	END IF;

	IF NEW.centre NOT IN ('Geylang', 'Ang Mo Kio', 'Woodlands') THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid YGOS Centre.';
	END IF;
    
-- 	IF EXISTS (SELECT * FROM Activity a WHERE a.activityDate = NEW.activityDate AND a.centre = NEW.centre AND a.topic != 'Sports' AND NEW.topic != 'Sports') THEN
-- 		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A Drop In Topic has already been scheduled for the specified DATE.';
-- 	END IF;
END;//
delimiter ;

CREATE TABLE Attends (
	startTime TIME NOT NULL,
	endTime TIME,
	youthNricNum CHAR(9),
	youthCentre CHAR(10),
	activityDate DATE,
	activityCentre VARCHAR(10),
	activityTopic VARCHAR(255),

	PRIMARY KEY (youthNricNum, youthCentre, activityDate, activityCentre, activityTopic),

	FOREIGN KEY (youthNricNum, youthCentre)
		REFERENCES Youth(nricNum, centre)
		ON DELETE CASCADE,

	FOREIGN KEY (activityDate, activityCentre, activityTopic)
		REFERENCES Activity(activityDate, centre, topic)
		ON DELETE CASCADE
);

delimiter //
CREATE TRIGGER valid_Attendance
	BEFORE
		INSERT 
	ON Attends FOR EACH ROW
BEGIN
-- 	IF NEW.startTime < SUBTIME(CURTIME(), '00:15:00') THEN
-- 		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'TIME IN cannot be earlier than current time.';
-- 	END IF;

-- 	IF EXISTS (
-- 		SELECT * FROM Attends a 
-- 		WHERE a.youthNricNum = NEW.youthNricNum 
-- 		AND a.activityDate = NEW.activityDate 
-- 		AND a.activityCentre = NEW.activityCentre 
-- 		AND a.youthCentre = NEW.youthCentre) THEN
-- 			SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Member has already checked in today.';
-- 	END IF;

	IF NEW.youthCentre != NEW.activityCentre THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Member cannot check in at a CENTRE which he/she is not registered in.';
	END IF;
END;//
delimiter ;

-- delimiter //
-- CREATE TRIGGER valid_Attendance_Update
-- 	BEFORE
-- 		UPDATE 
-- 	ON Attends FOR EACH ROW
-- BEGIN
-- 	IF EXISTS (
-- 		SELECT * FROM Attends a
-- 		WHERE a.youthMembershipNum = NEW.youthMembershipNum 
-- 		AND a.activityDate = NEW.activityDate 
-- 		AND a.activityCentre = NEW.activityCentre
-- 		AND a.youthCentre = NEW.youthCentre
-- 		AND a.endTime IS NULL
-- 		AND a.startTime > NEW.endTime) THEN
-- 			SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Check Out Time cannot be earlier than Check In Time.';
-- 	END IF;

-- 	IF NEW.endTime < SUBTIME(CURTIME(), '00:15:00') THEN
-- 		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'TIME OUT cannot be earlier than current time.';
-- 	END IF;

-- 	IF EXISTS (
-- 		SELECT * FROM Attends a 
-- 		WHERE a.youthMembershipNum = NEW.youthMembershipNum 
-- 		AND a.activityDate = NEW.activityDate 
-- 		AND a.activityCentre = NEW.activityCentre
-- 		AND a.youthCentre = NEW.youthCentre
-- 		AND a.endTime IS NOT NULL) THEN
-- 			SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Member has already checked out today.';
-- 	END IF;

-- 	IF NOT EXISTS (
-- 		SELECT * FROM Youth y
-- 		WHERE y.membershipNum = NEW.youthMembershipNum
-- 		AND y.centre = NEW.youthCentre) THEN
-- 			SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Membership Number is not registered.';
-- 	END IF;

-- 	IF NOT EXISTS (
-- 		SELECT * FROM Attends a
-- 		WHERE a.youthMembershipNum = NEW.youthMembershipNum 
-- 		AND a.activityDate = NEW.activityDate 
-- 		AND a.activityCentre = NEW.activityCentre
-- 		AND a.youthCentre = NEW.youthCentre) THEN
-- 			SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Member did not check in today.';
-- 	END IF;
-- END;//
-- delimiter ;

CREATE TABLE Users (
	userID CHAR(50) PRIMARY KEY,
	md5Hash CHAR(32),
	centre VARCHAR(10)
);

-- CREATE TABLE Posts (
-- 	postText VARCHAR(256),
-- 	postDate TIMESTAMP PRIMARY KEY
-- );